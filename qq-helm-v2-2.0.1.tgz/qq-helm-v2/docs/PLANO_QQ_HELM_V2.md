# Plano de Organizacao do Helm Chart v2

## Objetivo

Criar novo chart `qq-helm-v2` com `values.yaml` mais logico e semantico, mantendo capacidade de upgrade das instalacoes existentes e rollback via Helm.

O chart v1 atual continua publicado e usado pelos apps nao migrados.

## Decisao Principal

Publicar v2 como chart separado no Harbor.

Chart atual:

```bash
oci://harbor.mgm-k8s.qq/library/qq-helm/qq-helm
```

Novo chart:

```bash
oci://harbor.mgm-k8s.qq/library/qq-helm/qq-helm-v2
```

Motivo:

- evita upgrade acidental para v2 em pipelines antigos;
- permite migracao app por app;
- mantem v1 disponivel ate fim da migracao;
- reduz risco operacional;
- permite rollback normal pelo historico do release Helm.

## Estrategia de Repositorio Git

Nao atualizar a branch `main` com o chart v2.

A `main` hoje e usada por pipelines que fazem download direto pelo GitHub Helm repo. Qualquer alteracao no `index.yaml`, pacote `.tgz` ou chart publicado na `main` pode afetar apps ainda nao migrados.

Estrutura recomendada:

- `main`: manter somente chart v1 e pacotes v1 usados atualmente;
- `qq-helm-v2`: branch de desenvolvimento e manutencao do chart v2;
- Harbor: destino principal de publicacao do chart `qq-helm-v2`;
- GitHub v2: publicar somente se houver URL/repo separado, sem afetar `main`.

Criacao da branch:

```bash
git checkout -b qq-helm-v2
```

Regras:

- nao atualizar `index.yaml` da `main` com versao v2;
- nao publicar `qq-helm-v2` na `main` enquanto pipelines antigos dependerem dela;
- nao substituir pacote v1 existente;
- apps migrados devem apontar explicitamente para o chart v2 no Harbor;
- apps nao migrados continuam usando `main`/v1 sem alteracao.

## Comportamento de Versao

### Harbor OCI

Comando atual sem `--version`:

```bash
helm upgrade --install assinar-documentos \
  -n qqpag-svc-hml \
  --values apps/assinar-documentos/values.yml \
  oci://harbor.mgm-k8s.qq/library/qq-helm/qq-helm \
  --insecure-skip-tls-verify
```

Sem `--version`, Helm busca versao mais nova disponivel daquele chart.

Como v2 sera outro chart (`qq-helm-v2`), pipelines antigos continuam usando v1 mesmo sem pin de versao.

### GitHub Helm Repo

Comando atual:

```bash
helm upgrade --install verdemon-app-bff \
  -n qqpag-app-hml \
  --values values.yml \
  qq-helm/qq-helm
```

Sem `--version`, tambem busca versao mais nova do chart no `index.yaml`.

Se v2 fosse publicada no mesmo chart, haveria risco. Com chart separado, migracao tambem fica explicita.

## Upgrade e Rollback

Mesmo com chart separado, e possivel atualizar o release existente.

Exemplo de upgrade para v2:

```bash
helm upgrade assinar-documentos \
  -n qqpag-svc-hml \
  --values apps/assinar-documentos/values-v2.yml \
  oci://harbor.mgm-k8s.qq/library/qq-helm/qq-helm-v2 \
  --version 2.0.1 \
  --atomic \
  --timeout 5m \
  --insecure-skip-tls-verify
```

Helm mantem mesmo release `assinar-documentos`. Chart anterior pode ser `qq-helm` e novo pode ser `qq-helm-v2`.

Ver historico:

```bash
helm history assinar-documentos -n qqpag-svc-hml
```

Rollback manual:

```bash
helm rollback assinar-documentos 1 -n qqpag-svc-hml
```

`--atomic` faz rollback automatico se upgrade falhar.

## Regras Para Upgrade Seguro

O v2 deve preservar, por padrao:

- nome dos recursos principais;
- selectors antigos;
- label selector `app: <nome>`;
- nome do `Service`;
- nome do `Deployment` ou `StatefulSet`;
- nome do `ConfigMap` criado pelo chart;
- nome do `Secret` criado pelo chart;
- nome do PVC criado pelo chart;
- tipo de workload usado pelo app.

Evitar no mesmo upgrade:

- trocar `Deployment` por `StatefulSet`;
- trocar selector do workload;
- trocar nome do PVC;
- trocar `serviceName` de `StatefulSet`;
- alterar campos imutaveis do Kubernetes.

## Problemas do Chart Atual

- `values.yaml` mistura workload, rede, storage, env e scheduling no root.
- `envVarsRef` so renderiza se `envVars` existir.
- `startupProbe.command` usa `.Values.livenessProbe.command`.
- `cronJob.concurrencyPolicy` usa `backoffLimit`.
- `statefulSet` nao suporta volumes como `deployment`.
- HPA sempre aponta para `Deployment`.
- Ingress usa `service.targetPort` no backend, nao a porta do Service.
- Secret externo como env nao tem estrutura clara.
- Secret externo como volume nao e suportado.
- Helpers existem, mas sao pouco usados.

## Requisitos do v2

- possuir tudo que v1 possui;
- permitir montar volumes de Secrets nao criados pelo Helm;
- permitir incluir envs vindas de Secrets nao criados pelo Helm;
- organizar `values.yaml` de forma logica e semantica;
- permitir upgrade de releases existentes sem uninstall;
- permitir rollback via Helm;
- manter v1 funcionando ate migracao total.

## Estrutura Proposta do Values v2

```yaml
nameOverride: ""
fullnameOverride: ""

workload:
  enabled: true
  type: Deployment # Deployment | StatefulSet
  replicas: 1
  revisionHistoryLimit: 3
  strategy:
    type: RollingUpdate
    rollingUpdate:
      maxSurge: 25%
      maxUnavailable: 25%
  podAnnotations: {}
  podLabels: {}
  terminationGracePeriodSeconds: null

image:
  repository: nginx
  tag: stable-alpine
  pullPolicy: IfNotPresent
  pullSecrets:
    - name: nexus

container:
  name: ""
  command: []
  args: []
  ports:
    - name: http
      containerPort: 80
      protocol: TCP
  env:
    plain: {}
    valueFrom: []
    fromSecrets: []
    fromConfigMaps: []
  envFrom:
    configMaps: []
    secrets: []

initContainers: []

probes:
  startup:
    enabled: false
    periodSeconds: 10
    failureThreshold: 6
    httpGet: null
    exec: null
  liveness:
    enabled: false
    periodSeconds: 60
    initialDelaySeconds: 60
    httpGet: null
    exec: null

resources: {}

configMaps:
  create: false
  data: {}

secrets:
  create: false
  type: Opaque
  data: {}
  stringData: {}

volumes:
  pvc:
    create: false
    claims:
      - name: data
        claimName: ""
        size: 1Gi
        accessModes:
          - ReadWriteOnce
        storageClassName: longhorn
        mountPath: /data
  existing:
    - name: external-secret
      type: secret
      secretName: my-existing-secret
      mountPath: /etc/secrets
      readOnly: true

service:
  enabled: false
  type: ClusterIP
  annotations: {}
  ports:
    - name: http
      port: 80
      targetPort: http
      protocol: TCP

ingress:
  enabled: false
  className: nginx
  annotations: {}
  hosts:
    - host: dns.com.br
      paths:
        - path: /appverde_dev
          pathType: Prefix
          serviceName: ""
          servicePort: http
  tls: []

autoscaling:
  enabled: false
  minReplicas: 1
  maxReplicas: 2
  targetCPUUtilizationPercentage: null
  targetMemoryUtilizationPercentage: null

serviceMonitor:
  enabled: false
  labels:
    release: rancher-monitoring
  path: /metrics
  interval: 30s
  scrapeTimeout: 10s

scheduling:
  nodeSelector: {}
  tolerations: []
  affinity: {}

cronJobs: []
```

## Secret Externo Como Env

Values:

```yaml
container:
  env:
    fromSecrets:
      - name: DATABASE_PASSWORD
        secretName: app-db-secret
        key: password
      - name: API_TOKEN
        secretName: shared-api-secret
        key: token
```

Manifest esperado:

```yaml
env:
  - name: DATABASE_PASSWORD
    valueFrom:
      secretKeyRef:
        name: app-db-secret
        key: password
```

## Secret Externo Como Volume

Values:

```yaml
volumes:
  existing:
    - name: app-certificates
      type: secret
      secretName: app-tls-secret
      mountPath: /etc/tls
      readOnly: true
```

Manifest esperado:

```yaml
volumeMounts:
  - name: app-certificates
    mountPath: /etc/tls
    readOnly: true

volumes:
  - name: app-certificates
    secret:
      secretName: app-tls-secret
```

## Compatibilidade com v1

Mesmo sendo chart separado, v2 deve aceitar campos v1 durante transicao quando fizer sentido.

Mapeamento:

```yaml
application_name -> fullnameOverride ou nome preservado por helper
deployment.enabled/statefulSet.enabled -> workload.type + workload.enabled
replicas -> workload.replicas
image + imagePullPolicy -> image.repository/tag/pullPolicy
imagePullSecrets.name -> image.pullSecrets[]
envVars -> container.env.plain
envVarsRef -> container.env.valueFrom
configmap -> configMaps
secrets -> secrets
persistence + volumes -> volumes.pvc
hpa -> autoscaling
metrics -> serviceMonitor
tolerations/nodeSelector/affinity -> scheduling
```

Regra de prioridade:

- se valor novo existir, usar valor novo;
- senao, cair para valor antigo;
- manter manifests resultantes iguais quando app ainda usa values v1.

## Templates a Refatorar

- `_helpers.tpl`: nomes, labels, selectorLabels, target kind do HPA.
- `deployment.yaml`: Deployment com estrutura nova e fallback v1.
- `statefulset.yaml`: StatefulSet com suporte igual a volumes/env/probes.
- `service.yaml`: suporte a multiplas portas e fallback v1.
- `ingress.yaml`: multiplos hosts, className, tls e fallback v1.
- `configmap.yaml`: ConfigMap criado pelo chart.
- `secret.yaml`: Secret criado pelo chart com `data` e `stringData`.
- `pvc.yaml`: multiplos PVCs e fallback v1.
- `hpa.yaml`: target dinamico para Deployment ou StatefulSet.
- `service-monitor.yaml`: labels configuraveis.
- `cronJob.yaml`: corrigir campos e padronizar env/volumes se necessario.

## Estrategia de Migracao

1. Manter chart v1 atual publicado.
2. Manter branch `main` somente para v1.
3. Criar branch `qq-helm-v2` para desenvolvimento do novo chart.
4. Criar chart `qq-helm-v2`.
5. Publicar `qq-helm-v2` no Harbor.
6. Testar v2 com app piloto em homolog.
7. Migrar `values.yml` app por app para formato v2.
8. Fazer upgrade usando mesmo release e chart v2.
9. Usar `--atomic` em migracoes.
10. Fazer rollback se necessario.
11. Remover v1 apenas depois de migracao total e janela combinada.

## Comandos de Teste

Lint:

```bash
helm lint .
```

Render padrao:

```bash
helm template test . --values values.yaml
```

Render com app v1:

```bash
helm template test . --values examples/values-v1.yaml
```

Render com app v2:

```bash
helm template test . --values examples/values-v2.yaml
```

Render com Secret externo:

```bash
helm template test . --values examples/external-secret.yaml
```

## Criterios de Aceite

- apps v1 continuam usando chart antigo sem alteracao;
- branch `main` continua somente com v1;
- branch `qq-helm-v2` contem desenvolvimento/manutencao do v2;
- app piloto consegue upgrade para `qq-helm-v2` sem uninstall;
- rollback do app piloto funciona;
- Secret externo pode ser usado como env;
- Secret externo pode ser montado como volume;
- PVC existente nao e recriado se configurado;
- Deployment nao muda selector durante migracao;
- HPA aponta para workload correto;
- Ingress mantem comportamento atual quando usando formato v1;
- README mostra uso Harbor OCI e GitHub repo.

## Recomendacao Final

Seguir com `qq-helm-v2` separado no Harbor. O v2 deve ser organizado e suportar fallback v1 para reduzir risco, mas a migracao de cada app deve usar arquivo `values-v2.yml` proprio e upgrade com `--atomic`.
